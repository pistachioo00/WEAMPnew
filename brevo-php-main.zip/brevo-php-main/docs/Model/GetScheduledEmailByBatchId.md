# GetScheduledEmailByBatchId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Total number of batches | [optional] 
**batches** | [**\Brevo\Client\Model\GetScheduledEmailByBatchIdBatches[]**](GetScheduledEmailByBatchIdBatches.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

