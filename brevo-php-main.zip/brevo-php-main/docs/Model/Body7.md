# Body7

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**linkContactIds** | **int[]** | Contact ids for contacts to be linked with deal | [optional] 
**unlinkContactIds** | **int[]** | Contact ids for contacts to be unlinked from deal | [optional] 
**linkCompanyIds** | **string[]** | Company ids to be linked with deal | [optional] 
**unlinkCompanyIds** | **string[]** | Company ids to be unlinked from deal | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


