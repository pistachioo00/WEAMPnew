# GetExtendedCampaignOverviewSender

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Sender name of the campaign | [optional] 
**email** | **string** | Sender email of the campaign | [optional] 
**id** | **int** | Sender id of the campaign | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


