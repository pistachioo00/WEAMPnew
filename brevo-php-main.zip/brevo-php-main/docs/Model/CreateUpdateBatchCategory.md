# CreateUpdateBatchCategory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categories** | [**\Brevo\Client\Model\CreateUpdateCategories[]**](CreateUpdateCategories.md) | array of categories objects | 
**updateEnabled** | **bool** | Facilitate to update the existing categories in the same request (updateEnabled &#x3D; true) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


