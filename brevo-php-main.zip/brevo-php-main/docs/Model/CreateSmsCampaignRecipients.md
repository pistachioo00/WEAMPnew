# CreateSmsCampaignRecipients

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**listIds** | **int[]** | Lists Ids to send the campaign to. REQUIRED if scheduledAt is not empty | 
**exclusionListIds** | **int[]** | List ids which have to be excluded from a campaign | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


