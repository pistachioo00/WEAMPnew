# InviteuserPrivileges

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**feature** | **string** | Feature name | [optional] 
**permissions** | **string[]** | Permissions for a given feature | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


