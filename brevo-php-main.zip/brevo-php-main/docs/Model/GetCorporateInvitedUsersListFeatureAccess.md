# GetCorporateInvitedUsersListFeatureAccess

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userManagement** | **string[]** | User management accessiblity. | [optional] 
**apiKeys** | **string[]** | Api keys accessiblity. | [optional] 
**myPlan** | **string[]** | My plan accessiblity. | [optional] 
**appsManagement** | **string[]** | Apps management accessiblity | Not available in ENTv2 | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


