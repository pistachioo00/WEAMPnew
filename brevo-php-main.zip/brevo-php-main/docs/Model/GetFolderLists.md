# GetFolderLists

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lists** | **object[]** |  | [optional] 
**count** | **int** | Number of lists in the folder | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


