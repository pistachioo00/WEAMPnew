# GetUserPermissionPrivileges

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**feature** | **string** |  | 
**permissions** | **string[]** |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


