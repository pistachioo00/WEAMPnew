# MasterDetailsResponseBillingInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **string** | Billing email id of master account | [optional] 
**companyName** | **string** | Company name of master account | [optional] 
**name** | [**\Brevo\Client\Model\MasterDetailsResponseBillingInfoName**](MasterDetailsResponseBillingInfoName.md) |  | [optional] 
**address** | [**\Brevo\Client\Model\MasterDetailsResponseBillingInfoAddress**](MasterDetailsResponseBillingInfoAddress.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


