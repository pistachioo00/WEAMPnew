# RequestSmsRecipientExport

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**notifyURL** | **string** | URL that will be called once the export process is finished. For reference, https://help.brevo.com/hc/en-us/articles/360007666479 | [optional] 
**recipientsType** | **string** | Filter the recipients based on how they interacted with the campaign | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


