# Body1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupName** | **string** | The name of the group of sub-accounts | 
**subAccountIds** | **int[]** | Pass the list of sub-account Ids to be included in the group | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


