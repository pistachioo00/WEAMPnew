# CreateDomainModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | ID of the Domain created | 
**domainName** | **string** | Domain | [optional] 
**message** | **string** | Success message | [optional] 
**dnsRecords** | [**\Brevo\Client\Model\CreateDomainModelDnsRecords**](CreateDomainModelDnsRecords.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


