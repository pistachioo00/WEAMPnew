# GetInvitedUsersListFeatureAccess

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**marketing** | **object** | Marketing features accessiblity. | [optional] 
**conversations** | **object** | Conversations features accessiblity. | [optional] 
**crm** | **object** | CRM features accessiblity. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


