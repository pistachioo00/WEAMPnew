# GetChildrenList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**children** | **object[]** | Your children&#39;s account information | [optional] 
**count** | **int** | Number of child accounts | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


