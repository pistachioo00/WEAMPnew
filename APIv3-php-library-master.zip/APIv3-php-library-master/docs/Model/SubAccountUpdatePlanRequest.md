# SubAccountUpdatePlanRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credits** | [**\SendinBlue\Client\Model\SubAccountUpdatePlanRequestCredits**](SubAccountUpdatePlanRequestCredits.md) |  | [optional] 
**features** | [**\SendinBlue\Client\Model\SubAccountUpdatePlanRequestFeatures**](SubAccountUpdatePlanRequestFeatures.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


