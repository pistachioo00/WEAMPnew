# GetTransacBlockedContacts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Count of blocked or unsubscribed contact | [optional] 
**contacts** | [**\SendinBlue\Client\Model\GetTransacBlockedContactsContacts[]**](GetTransacBlockedContactsContacts.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


