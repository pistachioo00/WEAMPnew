# PostContactInfoContacts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **string[]** |  | [optional] 
**failure** | **string[]** |  | [optional] 
**total** | **int** | Displays the count of total number of contacts removed from list when user opts for \"all\" option. | [optional] 
**processId** | **int** | Id of the process created to remove contacts from list when user opts for \"all\" option. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


