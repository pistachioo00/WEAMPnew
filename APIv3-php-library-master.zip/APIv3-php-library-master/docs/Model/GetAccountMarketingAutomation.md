# GetAccountMarketingAutomation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **string** | Marketing Automation Tracker ID | [optional] 
**enabled** | **bool** | Status of Marketing Automation Plateform activation for your account (true&#x3D;enabled, false&#x3D;disabled) | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


