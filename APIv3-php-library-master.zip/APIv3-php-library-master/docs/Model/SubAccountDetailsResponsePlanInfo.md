# SubAccountDetailsResponsePlanInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credits** | [**\SendinBlue\Client\Model\SubAccountDetailsResponsePlanInfoCredits**](SubAccountDetailsResponsePlanInfoCredits.md) |  | [optional] 
**features** | [**\SendinBlue\Client\Model\SubAccountDetailsResponsePlanInfoFeatures**](SubAccountDetailsResponsePlanInfoFeatures.md) |  | [optional] 
**planType** | **string** | type of the plan | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


