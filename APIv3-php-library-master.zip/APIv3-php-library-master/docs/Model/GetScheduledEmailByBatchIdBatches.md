# GetScheduledEmailByBatchIdBatches

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scheduledAt** | [**\DateTime**] | Datetime for which the batch was scheduled | 
**createdAt** | [**\DateTime**] | Datetime on which the batch was scheduled | 
**status** | **string** | Current status of the scheduled batch | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

