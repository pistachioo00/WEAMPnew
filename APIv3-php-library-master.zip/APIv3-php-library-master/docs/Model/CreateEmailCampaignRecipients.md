# CreateEmailCampaignRecipients

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exclusionListIds** | **int[]** | List ids to exclude from the campaign | [optional] 
**listIds** | **int[]** | Mandatory if scheduledAt is not empty. List Ids to send the campaign to | [optional] 
**segmentIds** | **int[]** | Mandatory if listIds are not used. Segment ids to send the campaign to. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


