# GetClient

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **string** | Login Email | 
**firstName** | **string** | First Name | 
**lastName** | **string** | Last Name | 
**companyName** | **string** | Name of the company | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


