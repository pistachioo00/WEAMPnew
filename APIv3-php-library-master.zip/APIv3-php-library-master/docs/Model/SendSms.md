# SendSms

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reference** | **string** |  | 
**messageId** | **int** |  | 
**smsCount** | **int** | Count of SMS&#39;s to send multiple text messages | [optional] 
**usedCredits** | **float** | SMS credits used per text message | [optional] 
**remainingCredits** | **float** | Remaining SMS credits of the user | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


